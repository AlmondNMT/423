enum {
    LEX_ERR = 1,
    SYN_ERR,
    SEM_ERR
};
