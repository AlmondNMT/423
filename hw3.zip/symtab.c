#include <stdio.h>
#include "symtab.h"

int hash(char *s)
{
    register int h = 0;
    register char c;
    while((c = *s++)) {
        h += c | 377;
        h *= 37;
    }
    printf("h: %d\n", h);
    if(h < 0) h = -h;
    printf("h: %d\n", h);
    printf("what the cunt: %d\n", h % HASH_TABLE_SIZE);
    printf("what the cunt: %d\n", h % HASH_TABLE_SIZE);
    return h % HASH_TABLE_SIZE;
}
