#define HASH_TABLE_SIZE 1 << 30

typedef struct hash_table {
    
} hash_table_t;

typedef enum {
    SYMBOL_LOCAL,
    SYMBOL_PARAM,
    SYMBOL_GLOBAL
} symbol_kind;

typedef struct symbol {
    symbol_kind kind;
    struct type *type;
    char *name;
    int which;
} symbol_t;

// Prototypes TODO: write function definitions and determine return types
void scope_enter();
void scope_exit();
void scope_level();
void scope_bind(char *name, symbol_t *sym);
void scope_lookup(char *name);
void scope_lookup_current(char *name);
int hash(char *s);
