char *substring(char *s, int start, int end);
char *extract_string(char *s);
char *strip_underscores(char *s);
int extract_int(char *s);
double extract_float(char *s);
